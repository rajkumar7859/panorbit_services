import React from 'react'
import ProfileHomePage from './ProfileHomePage'

const Profile = () => {
  return (
    <div>
      <ProfileHomePage />
    </div>
  )
}

export default Profile
